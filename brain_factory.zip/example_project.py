"""
Example project: a tiny 2D creature.

The brain is only plain neurons. This project decides:
  - 12 neurons at the front are the eyes (sensors)
  - 6 neurons on the left drive the left wheel
  - 6 neurons on the right drive the right wheel
Everything else stays a plain neuron.

Run:  python example_project.py
Then: python view_brain.py neurons.csv connections.csv roles.csv
"""
from brain_roles import Brain

brain = Brain("neurons.csv")
brain.assign(brain.pick(12, side="front"), "sensor")
brain.assign(brain.pick(6, side="left"), "motor_left")
brain.assign(brain.pick(6, side="right"), "motor_right")
brain.save("roles.csv")
print("Saved roles.csv:", brain.summary())

# Later, in your simulation loop:
#   - push the world into the sensors  (add current to the "sensor" neurons)
#   - read the motors                  (more firing in motor_left than motor_right -> turn right)
