#!/usr/bin/env python3
"""
Give neurons jobs.

The brain is only plain neurons with a nucleus position. Your project decides
which neurons are sensors, which are motors, and so on. The brain never changes.

As a command:
    python brain_roles.py neurons.csv sensor=12:front motor_left=6:left motor_right=6:right

  Each job is  name=count:where
  where = left, right, top, bottom, front, back, or random
  (picks the free neurons farthest toward that side, in the order you list the jobs)
  Writes roles.csv (id, role). Neurons you don't mention stay plain neurons.

From your own project script:
    from brain_roles import Brain
    brain = Brain("neurons.csv")
    brain.assign(brain.pick(12, side="front"), "sensor")
    brain.assign(brain.pick(5, near=(10, 50, 50)), "motor")
    brain.save("roles.csv")
"""
import argparse
import csv
import random
import sys

# side -> (axis index, direction)
SIDES = {"left": (0, -1), "right": (0, 1), "bottom": (1, -1), "top": (1, 1),
         "back": (2, -1), "front": (2, 1)}


class Brain:
    def __init__(self, path="neurons.csv"):
        self.ids, self.pos, self.roles = [], {}, {}
        with open(path, newline="") as f:
            for i, row in enumerate(csv.DictReader(f)):
                nid = (row.get("id") or str(i)).strip()
                self.ids.append(nid)
                self.pos[nid] = (float(row["x"]), float(row["y"]), float(row["z"]))
        if not self.ids:
            raise ValueError(f"{path} has no neurons")

    def free(self):
        return [i for i in self.ids if i not in self.roles]

    def pick(self, count, side="random", near=None, seed=0):
        """Return `count` free neuron ids: toward a side, near a point, or random."""
        pool = self.free()
        if count > len(pool):
            raise ValueError(f"asked for {count} neurons but only {len(pool)} are free")
        if near is not None:
            return sorted(pool, key=lambda i: sum((a - b) ** 2 for a, b in zip(self.pos[i], near)))[:count]
        if side == "random":
            return random.Random(seed).sample(pool, count)
        if side not in SIDES:
            raise ValueError(f"where must be random or one of {', '.join(SIDES)}")
        axis, sign = SIDES[side]
        return sorted(pool, key=lambda i: -sign * self.pos[i][axis])[:count]

    def assign(self, ids, role):
        for i in ids:
            self.roles[i] = role

    def save(self, path="roles.csv"):
        with open(path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["id", "role"])
            w.writerows(self.roles.items())

    def summary(self):
        counts = {}
        for r in self.roles.values():
            counts[r] = counts.get(r, 0) + 1
        parts = [f"{r}: {c}" for r, c in counts.items()]
        parts.append(f"plain neurons: {len(self.ids) - len(self.roles)}")
        return ", ".join(parts)


def main():
    ap = argparse.ArgumentParser(description="Give neurons jobs.", epilog=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("neurons", help="neurons.csv")
    ap.add_argument("jobs", nargs="+", help="name=count:where, e.g. motor=6:left")
    ap.add_argument("--out", default="roles.csv")
    args = ap.parse_args()
    try:
        brain = Brain(args.neurons)
        for job in args.jobs:
            name, rest = job.split("=", 1)
            count, _, where = rest.partition(":")
            brain.assign(brain.pick(int(count), side=where or "random"), name.strip())
    except FileNotFoundError:
        sys.exit(f"Can't find {args.neurons}. Run this from the folder that has it.")
    except (ValueError, KeyError) as err:
        sys.exit(f"Error: {err}")
    brain.save(args.out)
    print(f"Saved {args.out}  ({brain.summary()})")


if __name__ == "__main__":
    main()
