Brain factory

1. python factory_brain.py                      makes neurons.csv  (--help for shapes, types, zones)
2. python connect_neurons.py                    makes connections.csv
3. python view_brain.py neurons.csv connections.csv     opens the viewer in your browser

Needs: Python 3 and numpy (pip install numpy). The viewer needs nothing extra.
Settings template: brain_config.json  (use with --config brain_config.json)
